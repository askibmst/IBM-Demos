from __future__ import print_function # In python 2.7
import sys
import os
import json
import requests
import config
import logging
try:
    import http.client as http_client
except ImportError:
    # Python 2
    import httplib as http_client
from flask import Flask, jsonify, request


app = Flask(__name__)

app.config.update(
    PROPAGATE_EXCEPTIONS = True
)

http_client.HTTPConnection.debuglevel = 1
logging.basicConfig()
logging.getLogger().setLevel(logging.DEBUG)
requests_log = logging.getLogger("requests.packages.urllib3")
requests_log.setLevel(logging.DEBUG)
requests_log.propagate = True

currentClient = []
currentGeoLong = ""
currentGeoLat = ""


@app.route('/')
def Welcome():
    return app.send_static_file('index.html')

@app.route('/configure')
def Configure():
    return app.send_static_file('configure.html')

@app.route('/discoverySearch', methods = ['POST'])
def search():
    global currentClient
    global currentGeoLong
    global currentGeoLat
    try:
        crequest = requests.post(config.searchUrl,json={'client': currentClient, 'input':request.get_data(), 'long':currentGeoLong, 'lat':currentGeoLat})
        jsonn = json.loads(crequest.text)
        return jsonify(jsonn)
    except:

        return jsonify({'Error': 'Bad Search'});

@app.route('/autocomplete', methods = ['POST'])
def autocomplete():
    global currentClient
    global currentGeoLong
    global currentGeoLat
    try:
        print("got data for autocomplete: " + request.get_data() , file=sys.stderr)
        crequest = requests.post(config.autocompleteUrl,json={'client': currentClient, 'input':request.get_data(), 'long':currentGeoLong, 'lat':currentGeoLat})
        jsonn = json.loads(crequest.text)
        return jsonify(jsonn)
    except:
        return jsonify({'Error': 'Bad Autocomplete'});

@app.route('/getPrediction', methods = ['GET'])
def getPrediction():
    global currentClient
    global currentGeoLong
    global currentGeoLat
    try:
        print("sending prediction for: " + currentClient[0] , file=sys.stderr)
        crequest = requests.post(config.predictionUrl,json={'client': currentClient[0]})
        jsonn = json.loads(crequest.text)
        return jsonify(jsonn)
    except:
        return jsonify({'Error':'Please choose a customer to analyze in the configuration page.'});


@app.route('/setClient/<client>', methods = ['GET','POST'])
def setClient(client):
    global currentClient
    global currentGeoLong
    global currentGeoLat
    currentClient = [client]
    return jsonify({'client':str(client)})

@app.route('/setGeoLocation/<clong>/<clat>', methods = ['GET','POST'])
def setGeoLocation(clong, clat):
    global currentClient
    global currentGeoLong
    global currentGeoLat
    currentGeoLong = clong
    currentGeoLat = clat
    return jsonify({'long':str(currentGeoLong), 'lat':str(currentGeoLat)})



port = os.getenv('PORT', '5000')
if __name__ == "__main__":
	app.run(host='0.0.0.0', port=int(port))

