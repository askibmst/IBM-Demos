predictionUrl = 'https://searchdemoapi.mybluemix.net/input'

autocompleteUrl = 'https://searchdemoapi.mybluemix.net/autocomplete'

searchUrl = 'https://searchdemoapi.mybluemix.net/search'



