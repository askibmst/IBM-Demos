/**
 * Created by johnhurdle on 10/10/17.
 */



var clients = [];

clients.push(['120021', 'Steve','Student','28','It\'s Complicated', "static/images/avatars/alexander.svg", "Cold Play", "U2", "Green Day", "", "Blancomeow", 'Facebook', '...Lately I only go to see Brand New...I really enjoy going to the Tabernacle in ATL...', '...Lately I only go to see Brand New...I really enjoy going to the Tabernacle in ATL...']);
clients.push(['14754', 'Katy','Blogger','32','Married', "static/images/avatars/alice.svg", "Florida Georgia Lina", "U2", "Tom Petty", "Jay Z", "Keturah18", 'Facebook','Mirror by Lil Wayne It\'s a really surprising song coming from him.','Mirror by Lil Wayne It\'s a really surprising song coming from him.']);
clients.push(['57005', 'Richard','Consultant','45','Single', "static/images/avatars/gregory.svg", "Jay Z", "Cold Play", "U2", "Tom Petty and The Heartbreakers", 'Moooomilk', 'Ticketmaster', 'Happy by Pharrell Williams. That song always puts me in an upbeat mood. lol', 'Happy by Pharrell Williams. That song always puts me in an upbeat mood. lol']);


var navMount = document.getElementById('nav-mount');

navMount.insertAdjacentHTML('afterbegin', '<div id="navContainer" class="navContainer"> </div>');

var scoringMount = document.getElementById('scoring-mount');

scoringMount.insertAdjacentHTML('afterbegin', '<div id="clientContainer" class="clientContainer"> </div>');

var clientContainer = document.getElementById('clientContainer');

document.getElementById('navContainer').insertAdjacentHTML('afterbegin', '<div id="'+ "navWrapper" + '" class="navWrapper"></div>');
document.getElementById('navWrapper').insertAdjacentHTML('beforeend', '<div id="'+ "navContent" + '" class="navContent" ></div>');
document.getElementById('navContent').insertAdjacentHTML('beforeend', '<div id="'+ "navDetails" + '" class="navDetails"></div>');
document.getElementById('navDetails').insertAdjacentHTML('beforeend', '<div id="homeImage" class="navImage"></div>');
document.getElementById('homeImage').style.backgroundImage = "url('static/images/home.png')";

document.getElementById('homeImage').addEventListener('click',function(event){
    window.location.href = '/';
},false);

var clientWrappers = [];
var clientContent = [];
var clientLabels = [];
var clientImages = [];
var clientDetails = [];

for (i = 0; i <clients.length; i++){


    clientWrappers.push("clientWrapper"+ String(i));
    clientContent.push("clientContent"+ String(i));
    clientLabels.push("clientLabels"+ String(i));
    clientImages.push("clientImages"+ String(i));
    clientDetails.push("clientDetails"+ String(i));
    clientContainer.insertAdjacentHTML('afterbegin', '<div id="'+ clientWrappers[i] + '" class="clientWrapper"></div>');
    document.getElementById(clientWrappers[i]).insertAdjacentHTML('afterbegin', '<div id="'+ String(clientContent[i]) + '" class="clientContent"></div>');
    document.getElementById(clientContent[i]).insertAdjacentHTML('beforeend', '<div id="'+ String(clientImages[i]) + '" class="clientImage" ></div>');
    document.getElementById(clientContent[i]).insertAdjacentHTML('beforeend', '<div id="'+ String(clientLabels[i]) + '" class="clientLabel"><h2>'+ String(clients[i][1]) + '</h2></div>');
    document.getElementById(clientContent[i]).insertAdjacentHTML('beforeend', '<img id="'+ String(clientDetails[i]) + '" class="clientDetails">' + clients[i][2] + ' | ' + clients[i][3] + ' | ' + clients[i][4] + '<br><br><h3>Favorite Artists</h3><br>' + String(clients[i][6]) + '<br>' + String(clients[i][7]) + '<br>' + String(clients[i][8]) + '<br>' + String(clients[i][9]) + '<br><br><h3>Linked Accounts</h3>' + String(clients[i][11]) + '</div>');
    document.getElementById(clientImages[i]).style.backgroundImage = "url('" + String(clients[i][5])  + "')";

}


function resetClientContentShadows() {

    for (y = 0; y < clients.length; y++) {

        document.getElementById(clientContent[y]).style = "color: ";

    }
}


for (x = 0; x <clients.length; x++) {

    document.getElementById(clientContent[x]).addEventListener('click',function(event){

        var xmlhttp = new XMLHttpRequest();

        xmlhttp.onreadystatechange = function (){
            if (xmlhttp.readyState ===4 && xmlhttp.status === 200) {
                            jsonn = JSON.parse(xmlhttp.responseText);
            }

        };
        resetClientContentShadows()
        event.currentTarget.style = "box-shadow: 0 4px 8px 0; color: #a00;"
        targetId = event.currentTarget.id;
        xmlhttp.open("POST", '/setClient/' + clients[targetId.substring(targetId.length-1,targetId.length)][0], true);
        xmlhttp.send();

        },false);

}
