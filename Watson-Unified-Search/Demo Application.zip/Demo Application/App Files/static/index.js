/**
 * Created by johnhurdle on 10/10/17.
 */

var predictionWrappers = [];
var predictionLabelWrappers = [];
var predictionDetailsWrappers = [];
var predictionLabelContent = [];
var predictionDetailsContent = [];
var predictionLabels = [];
var predictionDetails = [];
var timer;
var enableAuto = true;
var searchResults = [];
var lat;
var long;


var navMount = document.getElementById('nav-mount');

navMount.insertAdjacentHTML('afterbegin', '<div id="navContainer" class="navContainer"> </div>');

var searchBarMount = document.getElementById('searchBar-mount');

searchBarMount.insertAdjacentHTML('afterbegin', '<div id="searchBarContainer" class="searchBarContainer"> </div>');

var searchResultsMount = document.getElementById('searchResults-mount');

searchResultsMount.insertAdjacentHTML('afterbegin', '<div id="searchResultsContainer" class="searchResultsContainer"> </div>');

var predictionMount = document.getElementById('prediction-mount');

predictionMount.insertAdjacentHTML('beforeend', '<div id="predictionContainer" class="predictionContainer"> </div>');


document.getElementById('navContainer').insertAdjacentHTML('afterbegin', '<div id="'+ "navWrapper" + '" class="navWrapper"></div>');
document.getElementById('navWrapper').insertAdjacentHTML('beforeend', '<div id="'+ "navContent" + '" class="navContent" ></div>');
document.getElementById('navContent').insertAdjacentHTML('beforeend', '<div id="'+ "navDetails" + '" class="navDetails"></div>');
document.getElementById('navDetails').insertAdjacentHTML('beforeend', '<div id="settingsImage" class="navImage"></div>');
document.getElementById('settingsImage').style.backgroundImage = "url('static/images/settings.png')";

document.getElementById('settingsImage').addEventListener('click',function(event){
    window.location.href = '/configure';
},false);

document.getElementById('searchBarContainer').insertAdjacentHTML('afterbegin', '<div id="'+ "searchBarWrapper" + '" class="searchBarWrapper"></div>');
document.getElementById('searchBarWrapper').insertAdjacentHTML('beforeend', '<div id="'+ "searchBarContent" + '" class="searchBarContent" ></div>');
document.getElementById('searchBarContent').insertAdjacentHTML('beforeend', '<div id="'+ "searchBarDetails" + '" class="searchBarDetails"></div>');
document.getElementById('searchBarDetails').insertAdjacentHTML('beforeend', '<form id="searchBarForm"><input type="text", id="'+ "searchBarInput" + '" class="searchBarInput" value="Search Watson..."></input></form>');
document.getElementById('searchResultsContainer').insertAdjacentHTML('afterbegin', '<div id="'+ "searchResultsWrapper" + '" class="searchResultsWrapper"></div>');
document.getElementById('searchResultsWrapper').insertAdjacentHTML('beforeend', '<div id="'+ "searchResultsContent" + '" class="searchResultsContent" ></div>');


function removeSearchResultListing(){
    try{
        searchListing = document.getElementById('searchListingContainer')
        while (searchListing.hasChildNodes()) {
            searchListing.removeChild(searchListing.firstChild);
        }
    }
    catch(fail){}
}
function removeSearchResult(){
    try{
        searchListing = document.getElementById('searchResultsContent')
        while (searchListing.hasChildNodes()) {
            searchListing.removeChild(searchListing.firstChild);
        }
    }
    catch(fail){}
}


function renderSearchResultListing(searchListing){

    var searchListingMount = document.getElementById('searchListing-mount');

    searchListingMount.insertAdjacentHTML('afterbegin', '<div id="searchListingContainer" class="searchListingContainer"></div>');
    document.getElementById('searchListingContainer').insertAdjacentHTML('afterbegin', '<div id="searchListingWrapper" class="searchListingWrapper"></div>');
    document.getElementById('searchListingWrapper').insertAdjacentHTML('afterbegin', '<div id="searchListingContent" class="searchListingContent"></div>');
    document.getElementById('searchListingContent').insertAdjacentHTML('afterbegin', '<div id="searchListingDetails" class="searchListingDetails"><h3>' + searchListing.name + "</h3><br>" + searchListing.startdate + "-" + searchListing.enddate + "<br><br><br>" + searchListing.description + '</div>');
    document.getElementById('searchListingContent').insertAdjacentHTML('afterbegin', '<div id="searchListingNav" class="searchListingNav"></div>');
    document.getElementById('searchListingNav').insertAdjacentHTML('beforeend', '<div id="searchListingNavDetails" class="searchListingNavDetails"></div>');
    document.getElementById('searchListingNavDetails').insertAdjacentHTML('beforeend', '<div id="searchListingExitImage" class="navImage"></div>');
    document.getElementById('searchListingExitImage').style.backgroundImage = "url('static/images/exit.png')";

    document.getElementById('searchListingExitImage').addEventListener('click',function(event){
        removeSearchResultListing();
    },false);
}


function renderSearchResults() {
    for (y = 0; y < searchResults.length; y++) {
        document.getElementById('searchResultsContent').insertAdjacentHTML('beforeend', '<div id="' + "searchResultListing" + String(y) + '" class="searchResultListing" >' + searchResults[y].name + '</div>');
    }

    for (q = 0; q <searchResults.length; q++) {

    document.getElementById('searchResultListing'+String(q)).addEventListener('click',function(event){
        event.preventDefault();
        targetId = event.target.id;
        renderSearchResultListing(searchResults[targetId.substring(targetId.length-1,targetId.length)]);
    },false);

}
}

function renderAutoCompleteResults() {
    for (y = 0; y < searchResults.length; y++) {
        document.getElementById('searchResultsContent').insertAdjacentHTML('beforeend', '<div id="' + "searchResultListing" + String(y) + '" class="searchResultListing" >' + searchResults[y].name + '</div>');
    }

    for (q = 0; q <searchResults.length; q++) {

    document.getElementById('searchResultListing'+String(q)).addEventListener('click',function(event){
        event.preventDefault();
        document.getElementById("searchBarInput").value = this.innerText;
    },false);

}
}


document.getElementById('searchBarForm').addEventListener('submit',function(event){
    clearTimeout(timer);
    enableAuto = false;
    event.preventDefault();
    searchString = document.getElementById('searchBarInput').value.toString();
    discoverySearch(searchString);
},false);

document.getElementById('searchBarInput').addEventListener('click',function(event){
    searchBarInput = document.getElementById('searchBarInput');
   if (searchBarInput.value === 'Search Watson...') {
       searchBarInput.value = '';
       removeSearchResult();
    }

},false);

document.getElementById('searchBarInput').addEventListener('blur',function(event){
   searchBarInput = document.getElementById('searchBarInput');
   if (searchBarInput.value === '') {
       searchBarInput.value = 'Search Watson...';
    }

},false);


$('#searchBarInput').keyup(function(){
    if (this.value.length > 2 && enableAuto) {
        if (timer){
                clearTimeout(timer);
        }
        timer = setTimeout(function(){
                getAutocompleteListings(document.getElementById('searchBarInput').value);
        }, 800);
    }
});

function getPrediction(){
    document.getElementById('predictionContainer').insertAdjacentHTML('beforeend', '<div id="predictionLoadingImage" class="predictionLoadingImage"></div>');
    document.getElementById('predictionLoadingImage').style.backgroundImage = "url('static/images/watson_thinking.svg')";

    $.get( "/getPrediction", function( data ) {
        renderPrediction(data);
    });
}

function renderPrediction(prediction) {

    predictionWrappers = [];
    predictionLabelWrappers = [];
    predictionDetailsWrappers = [];
    predictionLabelContent = [];
    predictionDetailsContent = [];
    predictionLabels = [];
    predictionDetails = [];

    var predictionContainer = document.getElementById('predictionContainer');

    while (predictionContainer.hasChildNodes()) {
        predictionContainer.removeChild(predictionContainer.firstChild);
    }


    if (typeof(prediction.Error) === 'undefined') {

        for (i = 0; i < prediction.predictions.length; i++) {
            predictionWrappers.push("predictionWrapper" + String(i));
            predictionLabelWrappers.push("predictionLabelWrapper" + String(i));
            predictionDetailsWrappers.push("predictionDetailsWrapper" + String(i));
            predictionLabelContent.push("predictionLabelContent" + String(i));
            predictionLabels.push("predictionLabel" + String(i));
            predictionDetailsContent.push("predictionDetailsContent" + String(i));
            predictionDetails.push("predictionDetails" + String(i));
            predictionContainer.insertAdjacentHTML('beforeend', '<div id="' + predictionWrappers[i] + '" class="predictionWrapper"></div>');

            document.getElementById(predictionWrappers[i]).insertAdjacentHTML('beforeend', '<div id="' + String(predictionLabelWrappers[i]) + '" class="predictionLabelWrapper"></div>');
            document.getElementById(predictionWrappers[i]).insertAdjacentHTML('beforeend', '<div id="' + String(predictionDetailsWrappers[i]) + '" class="predictionDetailsWrapper"></div>');
            document.getElementById(predictionLabelWrappers[i]).insertAdjacentHTML('beforeend', '<div id="' + String(predictionLabelContent[i]) + '" class="predictionLabelContent"></div>');
            document.getElementById(predictionDetailsWrappers[i]).insertAdjacentHTML('beforeend', '<div id="' + String(predictionDetailsContent[i]) + '" class="predictionDetailsContent"></div>');
            document.getElementById(predictionLabelContent[i]).insertAdjacentHTML('beforeend', '<div id="' + String(predictionLabels[i]) + '" class="predictionLabel" ><h2>' + String(prediction.predictions[i].concert) + '</h2></div>');
            document.getElementById(predictionDetailsContent[i]).insertAdjacentHTML('beforeend', '<div id="' + String(predictionDetails[i]) + '" class="predictionDetails"><h3>' + String(prediction.predictions[i].source) + '</h3></div>');
        }
    }


    else{
            predictionWrappers.push("predictionWrapper0");
            predictionLabelWrappers.push("predictionLabelWrapper0");
            predictionDetailsWrappers.push("predictionDetailsWrapper0");
            predictionLabelContent.push("predictionLabelContent0");
            predictionLabels.push("predictionLabel0");
            predictionDetailsContent.push("predictionDetailsContent0");
            predictionDetails.push("predictionDetails0");
            predictionContainer.insertAdjacentHTML('afterbegin', '<div id="predictionWrapper0" class="predictionWrapper"></div>');

            document.getElementById('predictionWrapper0').insertAdjacentHTML('beforeend', '<div id="predictionErrorContent" class="predictionErrorContent"></div>');
            document.getElementById('predictionErrorContent').insertAdjacentHTML('beforeend', '<div id="predictionErrorDetails" class="predictionErrorDetails">' + prediction.Error + '</div>');
        }
}

function discoverySearch(inputString){
    document.getElementById("searchBarInput").value = "Watson is thinking...";
    $.post( "/discoverySearch",inputString, function( data ) {
            searchResults = data.results;
            removeSearchResult();
            renderSearchResults();
            document.getElementById("searchBarInput").value = "";
            clearTimeout(timer);
            enableAuto = true;
    });
}

function getAutocompleteListings(inputString){
    $.post( "/autocomplete",inputString, function( data ) {
            searchResults = data.results;
            removeSearchResult();
            renderAutoCompleteResults();
    });
}

function setGeoLocation(){

    var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function (){
            if (xmlhttp.readyState ===4 && xmlhttp.status === 200) {
                            jsonn = JSON.parse(xmlhttp.responseText);
            }
        };
        xmlhttp.open("POST", '/setGeoLocation/' + long + '/' + lat, true);
        xmlhttp.send();

}

function initGeolocation()
{
    if( navigator.geolocation )
    {
        // Call getCurrentPosition with success and failure callbacks
        navigator.geolocation.getCurrentPosition( function(position){

            lat = position.coords.latitude;
            long = position.coords.longitude;
            setGeoLocation();

        }, function(){});
    }
    else
    {
        alert("Sorry, your browser does not support geolocation services.");
    }
}
initGeolocation();
getPrediction();