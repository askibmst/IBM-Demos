
###########################
## Load libraries & data ##
###########################
library(shinydashboard)
library(shiny)
library(dplyr)
library(rgdal)
library(jsonlite)
library(httr)
library(devtools)
library(ggplot2)
library(leaflet)
library(merTools)
#devtools::install_github(repo = 'IBMDataScience/R4WML')
library(R4WML)


## "Get Weird" notebook output:  listings with predictions and reviews for those listings
portlandDF <- read.csv("portlandWithPredictions.csv", stringsAsFactors = F)
portlandReviewsDF <- read.csv("portlandReviews.csv", stringsAsFactors = F)

## GeoJSON for Portland Neighborhoods
pdxHoods <- rgdal::readOGR("neighbourhoods.geojson", "OGRGeoJSON")

###############
## Define UI ##
###############
shinyUI(dashboardPage(
  dashboardHeader(title = "Airbnb Explorer for Portland, Oregon", titleWidth = 450),
  dashboardSidebar(
    sidebarMenu(
      br(), br(),
      menuItem("Find Airbnbs", tabName = "FindAirbnbs", icon = icon("compass")),
      menuItem("Price Your Property", tabName = "pricing", icon = icon("usd")),
      menuItem("About", tabName = "about", icon = icon("question-circle")), 
      br(), br(),
      HTML('<hr style="border-color: black;">'),
      img(src = "https://onereach.com/img/watson_poweredby_black.svg", height = 130, width = 130)
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "FindAirbnbs",
              tags$style(type = "text/css", "#map {height: calc(90vh - 280px) !important;}"),
              fluidRow(
                
                ## Leaflet Map
                leafletOutput("map")
              ),
              
              fluidRow(
                
                p(),
                
                ## Listing Price valueBox
                valueBoxOutput("listingPrice", width = 3),
                
                ## Listing Details Box
                box(title = "Listing Details",
                    solidHeader = T, background = 'maroon', width = 4, height = 300,
                    htmlOutput("listingID"),
                    htmlOutput("neighborhood"),
                    htmlOutput("medianPrice"),
                    htmlOutput("propertyType"),
                    htmlOutput("roomType"),
                    htmlOutput("bedrooms"),
                    htmlOutput("bathrooms"),
                    htmlOutput("accommodates"),
                    htmlOutput("listingRange")
                ),
                
                ## Reviews with Watson Box
                box(title = "Reviews with Watson",
                    solidHeader = T, background = "navy", width = 4, height = 300,
                    htmlOutput("watsonSentimentType"),
                    htmlOutput("watsonSentimentScore"), 
                    htmlOutput("watsonEmotionJoy"),
                    htmlOutput("watsonEmotionSadness"),
                    htmlOutput("watsonEmotionAnger"),
                    htmlOutput("watsonEmotionDisgust"),
                    br(),
                    "Top 10 Keywords: ",
                    htmlOutput("watsonKeywords")
                )
              )
      ),
      
      tabItem(tabName = "pricing",
              fluidRow(
                column(width = 4,
                       wellPanel(
                         "Thinking of listing your property on Airbnb in Portland but aren't sure how to price it?  
                         Tell us about the property and we'll price it
                         relative to the market.", br(), hr(),
                         selectInput("hoodVar", "Which neighborhood?", choices = portlandDF$neighbourhood_cleansed),
                         selectInput("propertyVar", "Property type?", choices = portlandDF$property_type),
                         selectInput("roomVar", "Room type?", choices = portlandDF$room_type),
                         numericInput("bedroomsVar", "Bedrooms?", min = 0, max = 20, value = "", width = 75),
                         numericInput("bedsVar", "Beds?", min = 0, max = 20, value = "", width = 75),
                         numericInput("bathroomsVar", "Bathrooms?", min = 0, max = 20, value = "", width = 75),
                         numericInput("accommodatesVar", "Accommodates?", min = 0, max = 50, value = "", width = 75),
                         actionButton("getPrediction", "Find my Price")
                       )
                ),
                column(width = 8,
                       "Predicted price and range from mixed-effects model:", 
                       br(), br(),
                       valueBoxOutput("predictedPriceLwr"),
                       valueBoxOutput("predictedPrice"),
                       valueBoxOutput("predictedPriceUpr"),
                       br(),br(),
                       "Predicted price from gradient-boosted trees model:",
                       br(), br(),
                       infoBoxOutput("predictWML", width = 12),
                       plotOutput("priceComparePlot"))

              )
              
      ),
      
      tabItem(tabName = "about",
              h2("How to Use Airbnb Explorer"), br(),
              strong("Find Airbnbs"), br(),
              "This is a service for the Airbnb renter.  Find the right Airbnb for you by clicking on various listings on the map.  Listings that are considered fairly
              priced are colored in blue, while listings that fall outside of the market range are coded green
              and red.", br(), br(),
              "Specifications of the listing will be shown under", em( 'Listing Details'),".  After selecting a listing, 
              all of the reviews for that listing will be analyzed by Watson, with the output displayed under ", em("Reviews with Watson"),".  Try comparing different rentals 
              to see which has the strongest positive signals and relevant keywords.", br(), br(),
              strong("Price Your Property"), br(),
              "This is a service for the Airbnb owner.  Whether you are thinking of renting out your place or are merely curious as to how much you could ask for,
              we can provide this insight for you. After completing the forms your data will be scored against the 
              model and the results are shared graphically.", br(), br(),
              "Try to list your property at a price between the upper and lower bounds.  To help you with your decision,
              we've plotted the price range for your neighborhood (the boxplot in blue) alongside the price range for your
              property (the point and line in green).  It is generally advisable to keep the price of your listing within 
              the range of the boxplot.", br(), br(),
              strong("Mixed-Effects Models"), br(),
              "Play around with various neighborhoods, room types, and accommodation values.  It should become apparent
              that the predicted price is sensitive to both location and size variables, and that the effect size
              has depends on the location.  This is exactly what we wanted the mixed-effects model to capture!",
              br(), hr(),
              h4("Sources & Acknowledgements"), 
              a("Inside Airbnb", href="http://insideairbnb.com/"), br(),
              a("Mixed-Effects Models by Jared Knowles", 
                href = "https://www.jaredknowles.com/journal/2013/11/25/getting-started-with-mixed-effect-models-in-r"), br(),
              a("IBM Data Science Experience", href = "https://datascience.ibm.com/"), br(),
              a("IBM Watson APIs", href = "https://www.ibm.com/watson/developercloud/doc/natural-language-understanding/#categories"), br(),
              a("RStudio", href = "https://www.rstudio.com/"), hr(),
              "Built by: ", a("Rafi Kurlansik", href="mailto:rafi.kurlansik@ibm.com"), br()
              
      )
    ))
))