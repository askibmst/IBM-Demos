
## Install the R4WML library and define your credentials here
## This script is sourced by the Shiny App

## Make sure this is installed 
#devtools::install_github(repo = 'IBMDataScience/R4WML')
library(R4WML)

## WML Credentials ##
WMLtoken_url <- "https://ibm-watson-ml.mybluemix.net/v3/identity/token"
WMLusername <- "e4592642-e82b-421a-8c7f-47129f97dc86"
WMLpassword <- "8080f148-1bf8-43ab-bd5d-ee8a53346dde"

## Get WML token
WMLauth_token <- get_wml_auth_token(WMLtoken_url, WMLusername, WMLpassword)

## Get authentication headers
WMLurl <- "https://ibm-watson-ml.mybluemix.net"
WMLauth_headers <- get_wml_auth_headers(WMLurl, WMLusername, WMLpassword)



