

###########################
## Load libraries & data ##
###########################
library(shiny)
library(devtools)
library(merTools)

source("credentials.R")

## "Get Weird" notebook output:  listings with predictions and reviews for those listings
portlandDF <- read.csv("portlandWithPredictions.csv", stringsAsFactors = F)
portlandReviewsDF <- read.csv("portlandReviews.csv", stringsAsFactors = F)

## GeoJSON for Portland Neighborhoods
pdxHoods <- rgdal::readOGR("neighbourhoods.geojson", "OGRGeoJSON")

## Model for predictions
portMod <- readRDS(file = "portlandModel.rds")

#########################
## Define server logic ##
#########################
shinyServer(function(input, output) {
  
  ## Credentials for Watson NLU API
  username <- "533e2182-dc8f-4f35-82da-ae8ed2417a71"
  password <- "Szlm2Usfwn6t"
  base_url <- "https://gateway.watsonplatform.net/natural-language-understanding/api/v1/analyze?version=2017-02-27"
  
  watsonResponse <- ""
  
  ## Scoring endpoint for WML
  scoring_url <- "https://ibm-watson-ml.mybluemix.net/v3/wml_instances/6c28b97d-90d4-4013-bfc5-1afcc8a731ff/published_models/dc813f8f-9a4a-47c6-a377-2567bb06c70d/deployments/72db2989-93cc-4497-bac1-664e1fb44c1c/online"
  
  
  # Reactive values to store various click positions
  onMarkerClick <- reactiveValues(clickedMarker = NULL)
  onMapClick <- reactiveValues(clickedMap = NULL)
  onShapeClick <- reactiveValues(clickedShape = NULL)
  
  ## Update the reactive value based on click input
  observeEvent(input$map_marker_click,{
    onMarkerClick$clickedMarker <- input$map_marker_click
    print(onMarkerClick$clickedMarker)})
  
  observeEvent(input$map_click,{
    onMapClick$clickedMap <- NULL
    print(onMapClick$clickedMap)})
  
  observeEvent(input$map_shape_click, {
    onShapeClick$clickedShape <- input$map_shape_click
    print(onShapeClick$clickedShape)})
  
  
  #################
  ## Leaflet Map ##
  #################
  ## Lat/long for listings
  points <- portlandDF[, c('id', 'latitude', 'longitude')]
  
  ## Color palette for price level
  colors <- ifelse(portlandDF$actual > portlandDF$upr, "red", "lightblue")
  colors <- ifelse(portlandDF$actual < portlandDF$lwr, "green", colors)
  
  ## Select icon for markers
  icons <- awesomeIcons(
    icon = 'bed',
    iconColor = 'black',
    library = 'fa',
    markerColor = colors
  )
  
  ## Render map and options
  output$map <- renderLeaflet({
    leaflet(portlandDF) %>%
      setView(zoom = 12, lat = 45.5231, lng = -122.6765) %>%
      addProviderTiles(providers$Stamen.Terrain,
                       options = providerTileOptions(noWrap = TRUE)
      ) %>%
      addPolygons(data = pdxHoods, weight = 3, fill = F, color = "black", opacity = 1) %>%
      addPolygons(data = pdxHoods, weight = 1, fill = T, color = 'grey', opacity = 0.15,
                  label = ~as.character(pdxHoods$neighbourhood),
                  highlightOptions = highlightOptions(
                    color='#00ff00', opacity = 0.25, weight = 2, fillOpacity = 0.45,
                    bringToFront = TRUE, sendToBack = TRUE),
                  layerId = ~neighbourhood) %>%
      # addCircleMarkers(data = points, radius = 5, weight = 3)
      addAwesomeMarkers(data = points, icon = icons, layerId = ~id ) %>%
      addLegend("topleft", colors = c("lightblue", "green", "red"), 
                labels = c("Fair", "Underpriced", "Overpriced"), 
                values = ~price_level, title = "Relative Price Level", opacity = 1)
  })   
  
  
  ############################
  ## Listing Price Valuebox ##
  ############################
  output$listingPrice <- renderValueBox({
    valueBox(paste0(portlandDF[portlandDF$id == onMarkerClick$clickedMarker$id, "actual"], ".00"),
             "Listing Price",
             icon = icon("usd"))
  })
  
  #########################
  ## Listing Details Box ##
  #########################
  output$listingID <- renderText({paste0("Listing ID: ", onMarkerClick$clickedMarker$id)})
  
  output$neighborhood <- renderText({
    paste0("Neighborhood: ",
           portlandDF[portlandDF$id == onMarkerClick$clickedMarker$id, "neighbourhood_cleansed"])
  }) 
  
  output$medianPrice <- renderText({
    paste0("Median Price: ",
           "$",
           portlandDF[portlandDF$id == onMarkerClick$clickedMarker$id, "median_price"])
  })
  
  output$propertyType <- renderText({
    paste0("Property Type: ",
           portlandDF[portlandDF$id == onMarkerClick$clickedMarker$id, "property_type"])
  })
  
  output$roomType <- renderText({
    paste0("Room Type: ",
           portlandDF[portlandDF$id == onMarkerClick$clickedMarker$id, "room_type"])
  })
  
  output$listingRange <- renderText({
    paste0("Predicted Price Range: ",
           "$",
           portlandDF[portlandDF$id == onMarkerClick$clickedMarker$id, "lwr"],
           "-",
           "$",
           portlandDF[portlandDF$id == onMarkerClick$clickedMarker$id, "upr"])
  })
  
  output$bedrooms <- renderText({
    paste0("Bedrooms: ", 
           portlandDF[portlandDF$id == onMarkerClick$clickedMarker$id, "bedrooms"])
  })
  
  output$bathrooms <- renderText({
    paste0("Bathrooms: ",
           portlandDF[portlandDF$id == onMarkerClick$clickedMarker$id, "bathrooms"])
  })
  
  output$accommodates <- renderText({
    paste0("Accommodates: ",
           portlandDF[portlandDF$id == onMarkerClick$clickedMarker$id, "accommodates"])
  })
  
  
  #########################
  ## Reviews Summary Box ##
  #########################
  ## Listen for click
  observeEvent(input$map_marker_click, {
    
    ## Isolate reviews for listing that was clicked on
    reviews <- paste(portlandReviewsDF[portlandReviewsDF$listing_id == onMarkerClick$clickedMarker$id, "comments"], collapse = " ")
    
    ## Formulate payload for Watson API
    body <- list(text = reviews, 
                 features = list(
                   categories = {},
                   keywords = {},
                   emotion = {},
                   sentiment = {}),
                 language = 'en',
                 return_analyzed_text = TRUE)
    
    ## Hit API and save response
    watsonResponse  <- POST(base_url,
                            content_type_json(),
                            authenticate(username, password, type = "basic"),
                            body = toJSON(body, auto_unbox = T))
    
    ## Sentiment type, then score
    output$watsonSentimentType <- renderText({
      if(is.null(input$map_marker_click)) {
        return()
      } else{
        paste0(
          "Sentiment Type: ",
          fromJSON(toJSON(content(watsonResponse), pretty = T), flatten = T)$sentiment[[1]][[2]]
        )
      }
    })
    
    output$watsonSentimentScore <- renderText({
      if(is.null(input$map_marker_click)) {
        return()
      } else {
        paste0(
          "Score: ",
          fromJSON(toJSON(content(watsonResponse), pretty = T), flatten = T)$sentiment[[1]][[1]][1]
        )
      }
    })
    
    ## Emotion signals - Sadness, Joy, Anger, Disgust
    output$watsonEmotionSadness <- renderText({
      if(is.null(input$map_marker_click)) {
        return()
      } else {
        paste0(
          "Sadness Signal:  ",
          fromJSON(toJSON(content(watsonResponse), pretty = T), flatten = T)$emotion$document$emotion$sadness*100
        )
      }
    })
    
    output$watsonEmotionJoy <- renderText({
      if(is.null(input$map_marker_click)) {
        return()
      } else {
        paste0(
          "Joy Signal: ",
          fromJSON(toJSON(content(watsonResponse), pretty = T), flatten = T)$emotion$document$emotion$joy*100
        )
      }
    })
    
    output$watsonEmotionAnger <- renderText({
      if(is.null(input$map_marker_click)) {
        return()
      } else {
        paste0(
          "Anger Signal: ",
          fromJSON(toJSON(content(watsonResponse), pretty = T), flatten = T)$emotion$document$emotion$anger*100
        )
      }
    })
    
    output$watsonEmotionDisgust <- renderText({
      if(is.null(input$map_marker_click)) {
        return()
      } else {
        paste0(
          "Disgust Signal: ",
          fromJSON(toJSON(content(watsonResponse), pretty = T), flatten = T)$emotion$document$emotion$disgust*100
        )
      }
    })
    
    ## Top 5 keywords extracted from the reviews
    output$watsonKeywords <- renderText({
      if(is.null(input$map_marker_click)) {
        return()
      } else {
        paste0(unlist(fromJSON(toJSON(content(watsonResponse), pretty = T), flatten = T)$keywords[1:10, 'text']), sep = ",")
      }
    })
    
  })
  
  
  #############################
  ## Price Your Property Tab ##
  #############################
  ## Create row to predict
  
  toPredict <- eventReactive(input$getPrediction,{
    
    toPredictDF <- data.frame(neighbourhood_cleansed = input$hoodVar,
                              property_type = input$propertyVar,
                              room_type = input$roomVar,
                              bedrooms = input$bedroomsVar,
                              bathrooms = input$bathroomsVar,
                              accommodates = input$accommodatesVar)
    
    toPredictDF$compositeSize <- (toPredictDF$accommodates * 0.120499478974719 +
                                    toPredictDF$bathrooms * 0.101277602847124 +
                                    toPredictDF$bedrooms * 0.117804333680884)/0.3561081
    
    toPredictDF <- apply(merTools::predictInterval(portMod, toPredictDF, level = 0.95), 2, exp)
    
  })
  
  output$predictedPrice <- renderValueBox({
    valueBox(paste0(
      "$",
      round(toPredict()[1])),
      subtitle = "Predicted Price", color = 'teal', icon = icon('balance-scale')
    )
  })
  
  output$predictedPriceUpr <- renderValueBox({
    valueBox(paste0(
      "$",
      round(toPredict()[[2]])),
      subtitle = "Upper Bound", color = "orange", icon = icon('warning')
    )
  })
  
  output$predictedPriceLwr <- renderValueBox({
    valueBox(paste0(
      "$",
      round(toPredict()[[3]])),
      subtitle = "Lower Bound", color = "green", icon = icon('hand-stop-o')
    )
  })
  
  
  output$priceComparePlot <- renderPlot({
    
    toPlot <- data.frame(fit = toPredict()[1],
                         upr = toPredict()[2],
                         lwr = toPredict()[3],
                         neighbourhood_cleansed = input$hoodVar)
    
    ggplot(portlandDF[portlandDF$neighbourhood_cleansed == input$hoodVar, ], 
           aes(x = input$hoodVar, y = actual)) + 
      geom_boxplot(color = 'lightslateblue', fill = 'white', alpha = 0.75) + 
      geom_pointrange(data = toPlot, 
                      aes(y = toPlot$fit, x = toPlot$neighbourhood_cleansed, ymax = toPlot$upr, ymin = toPlot$lwr),
                      position = 'jitter', 
                      color = 'darkgreen', size = 2, alpha = 0.75) + 
      labs(x = "Neighborhood", y = "Price Range", title = "Price Compared to Neighborhood") + 
      theme_minimal()
  })
  
  ######################
  ## Predict with WML ##
  ######################
  
  ## Reactive output for WML
  toPredictWML <- eventReactive(input$getPrediction,{
    
    toPredictDF <- data.frame(neighbourhood_cleansed = input$hoodVar,
                              property_type = input$propertyVar,
                              room_type = input$roomVar,
                              bedrooms = input$bedroomsVar,
                              bathrooms = input$bathroomsVar,
                              accommodates = input$accommodatesVar,
                              beds = input$bedsVar)
    
    toPredictDF$compositeSize <- (toPredictDF$accommodates * 0.120499478974719 +
                                    toPredictDF$bathrooms * 0.101277602847124 +
                                    toPredictDF$bedrooms * 0.117804333680884)/0.3561081
    
    ## Convert dataframe to WML payload
    scoringSample <- to_wml_payload(toPredictDF)
    
    ## Send payload to WML
    results <- wml_score(scoring_url, WMLauth_headers, payload = scoringSample)
    
    ## Convert API response to DataFrame
    resultsDF <- from_wml_payload(results)
    
    results
    
  })
  
  ## Render WML results
  output$predictWML <- renderValueBox({
    
    infoBox(title = "Estimated Rental Price",
            subtitle = "Scored with Watson Machine Learning",
            value = paste0("$", round(exp(toPredictWML()$values[[1]][[10]]))),
            color = "maroon", 
            icon = icon('bullseye')
    )
    
  })
  
  
})


